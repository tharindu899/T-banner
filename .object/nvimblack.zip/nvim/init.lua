-- This file simply bootstraps the installation of Lazy.nvim and then calls other files for execution
-- This file doesn't necessarily need to be touched, BE CAUTIOUS editing this file and proceed at your own risk.
local lazypath = vim.env.LAZY or vim.fn.stdpath "data" .. "/lazy/lazy.nvim"
if not (vim.env.LAZY or (vim.uv or vim.loop).fs_stat(lazypath)) then
  -- stylua: ignore
  vim.fn.system({ "git", "clone", "--filter=blob:none", "https://github.com/folke/lazy.nvim.git", "--branch=stable", lazypath })
end
vim.opt.rtp:prepend(lazypath)

-- validate that lazy is available
if not pcall(require, "lazy") then
  -- stylua: ignore
  vim.api.nvim_echo({ { ("Unable to load lazy from: %s\n"):format(lazypath), "ErrorMsg" }, { "Press any key to exit...", "MoreMsg" } }, true, {})
  vim.fn.getchar()
  vim.cmd.quit()
end

require "lazy_setup"
require "polish"

-- Automatically install mason.nvim if it's not already set up
require("mason").setup()

-- Automatically install LSP servers
require("mason-lspconfig").setup({
    ensure_installed = {
        "cssls",             -- CSS LSP
        --"css",              -- HTML LSP
        "eslint",            -- ESLint LSP
        --"emmet_ls",          -- Emmet LSP
        "pyright",           -- Python LSP (if needed)
        --"emmet-language-server"
    }
})

-- User settings for line numbers
vim.opt.number = true                -- Enable line numbers
vim.opt.relativenumber = false        -- Enable relative line numbers

require 'nvim-treesitter.configs'.setup {
  -- Required fields
  ensure_installed = { "css", "javascript" },  -- Only CSS parser

  -- Additional required fields
  sync_install = false,  -- Whether to install parsers synchronously (recommended to keep false)
  auto_install = true,    -- Automatically install missing parsers when entering buffer
  ignore_install = {},     -- List of parsers to ignore installing (if any)

  highlight = {
    enable = true,  -- Enable Treesitter-based syntax highlighting
    additional_vim_regex_highlighting = false,  -- Use only Treesitter for highlighting
  },

  indent = {
    enable = true,  -- Enable Treesitter-based indentation
  },

  -- Optionally configure modules if needed
  modules = {},  -- You can specify which modules to enable (leave empty for default)
}
